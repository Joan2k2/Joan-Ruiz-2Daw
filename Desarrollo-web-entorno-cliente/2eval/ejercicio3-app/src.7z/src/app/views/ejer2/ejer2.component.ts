import { Component } from '@angular/core';

@Component({
  selector: 'app-ejer2',
  standalone: true,
  imports: [],
  templateUrl: './ejer2.component.html',
  styleUrl: './ejer2.component.css'
})
export class Ejer2Component {

}
