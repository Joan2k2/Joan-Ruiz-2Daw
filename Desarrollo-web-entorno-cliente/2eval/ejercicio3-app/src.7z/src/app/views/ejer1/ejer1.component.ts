import { Component } from '@angular/core';

@Component({
  selector: 'app-ejer1',
  standalone: true,
  imports: [],
  templateUrl: './ejer1.component.html',
  styleUrl: './ejer1.component.css'
})
export class Ejer1Component {

}
