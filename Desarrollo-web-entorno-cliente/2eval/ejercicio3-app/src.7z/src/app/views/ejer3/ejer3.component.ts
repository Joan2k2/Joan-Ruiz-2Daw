import { Component } from '@angular/core';

@Component({
  selector: 'app-ejer3',
  standalone: true,
  imports: [],
  templateUrl: './ejer3.component.html',
  styleUrl: './ejer3.component.css'
})
export class Ejer3Component {

}
