import { Component } from '@angular/core';

@Component({
  selector: 'app-view-one',
  standalone: true,
  imports: [],
  templateUrl: './view-one.component.html',
  styleUrl: './view-one.component.css'
})
export class ViewOneComponent {

}
