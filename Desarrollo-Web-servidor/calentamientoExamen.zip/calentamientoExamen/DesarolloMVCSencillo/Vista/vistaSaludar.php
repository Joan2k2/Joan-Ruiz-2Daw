<?php

class VistaSaludar{
//saluda
    function saludar($tiempo){
        
        echo"<h1>Saludos navegante son las {$tiempo}</h1>";

    }

    
}




?>