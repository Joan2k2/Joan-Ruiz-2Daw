<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use App\Controller\SecurityController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\RedirectController;
use Symfony\Component\HttpFoundation\Request;
use App\Form\FormularioType;
use App\Entity\Cliente;
use App\Entity\Dept;
use App\Entity\EMP;
use app\Entity\User;
use Doctrine\ORM\EntityManagerInterface;


class ClienteController extends AbstractController
{
    private $em;
    public function __construct(EntityManagerInterface $em){
        $this->em=$em;
    }
    //muestra la base de la pagina web
    #[Route('/', name: 'raiz')]
    public function index(): Response
    {
        return $this->render('templatemo_287_ancient/index.html.twig', [
            'controller_name' => 'ProductController',
        ]);
    }

    //muestra todos los clientes
    #[Route('/cliente', name: 'all_cliente')]
    public function show(EntityManagerInterface $entityManager): Response
    {
        $product = $entityManager->getRepository(Cliente::class)->findAll();
        


         return $this->render('templatemo_287_ancient/cliente.html.twig', [
             'resultados' => $product,
         ]);

        // or render a template
        // in the template, print things with {{ product.name }}
        // return $this->render('product/show.html.twig', ['product' => $product]);
    }
    //muestra los detalles de un cliente
    #[Route('/detail/{id}', name: 'one_cliente')]
    public function detail(EntityManagerInterface $entityManager,int $id): Response
    {
        $producto=$entityManager->getRepository(Cliente::class)->find($id);
        
        

         return $this->render('templatemo_287_ancient/detail.html.twig', [
             'resultados' => $producto,
         ]);

        // or render a template
        // in the template, print things with {{ product.name }}
        // return $this->render('product/show.html.twig', ['product' => $product]);
    }
    //muestra todos los empleados
    #[Route('/emp', name: 'all_emp')]
    public function showemp(EntityManagerInterface $entityManager): Response
    {
        $product = $entityManager->getRepository(EMP::class)->findAll();
        for($i=0;$i<count($product);$i++){
            $result[]=$product[$i]->getDeptNo2()->getId();
        }


        return $this->render('templatemo_287_ancient/emp.html.twig', [
            'resultados' => $result, 'result' => $product,
        ]);
/*
         return $this->render('templatemo_287_ancient/emp.html.twig', [
             'resultados' => $product,
         ]);



        <td>{{row.getId}}</td>
        <td>{{row.getApellidos}}</td>
        <td>{{row.getDeptNo2-getId}}</td>
*/
        // or render a template
        // in the template, print things with {{ product.name }}
        // return $this->render('product/show.html.twig', ['product' => $product]);
    }

    //hace un insert de cliente
    #[Route('/insert', name: 'create_product')]
    public function createProduct(EntityManagerInterface $entityManager): Response
    {
        $cliente = new Cliente();
        $cliente->setNombre('davit');
        $cliente->setDirec('aleluya');
        $cliente->setArea(2);
        $cliente->setCiudad('massanassa');
        $cliente->setCodPostal(5560);
        $cliente->setEstado('holiii');
        $cliente->setLimiteCredito(225);
        $cliente->setObservaciones('todo bien');
        $cliente->setReprCod(1);
        $cliente->setTelefono(5555);
        

        // tell Doctrine you want to (eventually) save the Product (no queries yet)
        $entityManager->persist($cliente);

        // actually executes the queries (i.e. the INSERT query)
        $entityManager->flush();

        return new Response('Saved new product with id '.$cliente->getId());
    }

    //hace un insert en departamento
    #[Route('/insert_dept', name: 'create_dept')]
    public function createdept(EntityManagerInterface $entityManager): Response
    {
        $dept = new Dept();
        $dept->setColor('amarillo');
        $dept->setDnombre('sol');
        $dept->setLoc('grande');

        

        // tell Doctrine you want to (eventually) save the Product (no queries yet)
        $entityManager->persist($dept);

        // actually executes the queries (i.e. the INSERT query)
        $entityManager->flush();

        return new Response('Saved new product with id '.$dept->getId());
    }
    //hace un insert en empleado
    #[Route('/insert_emp', name: 'create_emp')]
    public function createemp(EntityManagerInterface $entityManager): Response
    {
        $date = new \DateTime('@'.strtotime('now'));
        $product = $entityManager->getRepository(Dept::class)->find(4);
        $emp = new EMP();
        $emp->setApellidos('jorge');
        $emp->setComision(21);
        $emp->setDeptNo(4);
        $emp->setDeptNo2($product);
        $emp->setFechaAlta($date);
        $emp->setJefe(1);
        $emp->setOficio('nose');
        $emp->setSalario(300);
        

        // tell Doctrine you want to (eventually) save the Product (no queries yet)
        $entityManager->persist($emp);

        // actually executes the queries (i.e. the INSERT query)
        $entityManager->flush();

        return new Response('Saved new product with id '.$emp->getId());
    }
    //elimina un empleado
    #[Route('/product/delete/{id}', name: 'product_delete')]
    public function delete(EntityManagerInterface $entityManager, int $id): Response
    {

        
        $product = $entityManager->getRepository(EMP::class)->find($id);

        if (!$product) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        $entityManager->remove($product);
        $entityManager->flush();

        return new Response('fue eliminado');
        
    }
    //elimina un cliente
    #[Route('/delete/{id}', name: 'cliente_delete')]
    public function deletecliente(EntityManagerInterface $entityManager, int $id): Response
    {

        
        $product = $entityManager->getRepository(Cliente::class)->find($id);

        if (!$product) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        $entityManager->remove($product);
        $entityManager->flush();

        return $this->redirectToRoute('all_cliente');
        
    }

    //muestra un form para crear un nuevo cliente
    #[Route('/insertt', name: 'app_form')]
    public function indice(Request $request): Response
    {

        $producto=new Cliente();
        $form = $this->createForm(FormularioType::class, $producto);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $this->em->persist($producto);
            $this->em->flush();
            return $this->redirectToRoute('all_cliente');
        }
        return $this->render('base.html.twig', [
            'form' => $form->createView()
        ]);
    }
    //muestra un form para actualizar un cliente
    #[Route('/update/{id}', name: 'update_form')]
    public function update(Request $request, EntityManagerInterface $entityManager, int $id): Response
    {

        $producto=$entityManager->getRepository(Cliente::class)->find($id);
        $form = $this->createForm(FormularioType::class, $producto);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $this->em->persist($producto);
            $this->em->flush();
            return $this->redirectToRoute('all_cliente');
        }
        return $this->render('base.html.twig', [
            'form' => $form->createView()
        ]);
    }
}
