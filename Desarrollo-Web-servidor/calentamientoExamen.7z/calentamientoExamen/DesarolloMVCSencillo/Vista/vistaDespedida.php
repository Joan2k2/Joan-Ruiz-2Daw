<?php

class VistaDespedida{
//muestra una despedida
    function despedirse($tiempo){
        
        echo"<h1>Adios navegante son las {$tiempo}</h1>";

    }

    
}




?>