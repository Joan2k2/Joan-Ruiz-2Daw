<?php

interface Forma{
    public function calcularArea();
}

?>