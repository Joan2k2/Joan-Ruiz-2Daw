    <!DOCTYPE html>
    <html lang="en">

    <body>
        <h2>


            <?php

            $array = array(6, 9, 189);
            $min = (min($array));
            $max = (max($array));

            print("El numero menor del array es " . $min . " El numero mayor del array es " . $max);

            ?>
        </h2>
    </body>

    </html>