
<?php

class Cuadrado extends Figura{





    
}


?>